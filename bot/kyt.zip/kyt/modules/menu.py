from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline(" SSH MANAGER ", "ssh")]
    ]
    
    sh = f'cat /etc/ssh/.ssh.db | grep "###" | wc -l'
    ssh = subprocess.check_output(sh, shell=True).decode("ascii")

    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
     **🇮🇩🇮🇩 FanoraVpnTunnel 🇮🇩🇮🇩**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» 🌹Total Account Created 🌹** 
**» ⚠️SSH OVPN    :** `{ssh.strip()}` __account__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    x = await event.edit(msg, buttons=inline)
    if not x:
        await event.reply(msg, buttons=inline)

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh_manager(event):
    # Logika untuk menangani event klik pada tombol SSH Manager
    # Misalnya, tampilkan menu SSH Manager atau lakukan tindakan lain sesuai kebutuhan
    await event.answer("SSH Manager di Klik!")
